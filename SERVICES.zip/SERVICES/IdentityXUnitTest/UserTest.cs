using iCLASSES;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using Xunit;
using IdentityService.Controllers;

namespace IdentityXUnitTest
{
    public class UserTest
    {
        [Fact]
        public void PostUSER_PostSingleUser()
        {
            iDTO.PostUSER newUser = new iDTO.PostUSER
            {
                NAME = "Joshua Ola",
                EMAIL = "joshuaola95@gmail.com",
                PASSWORD = "LOL"
            };

            var result = new  UserController();
            var rr = result.PostUSER(newUser) as iDTO.PostUSER;
            Assert.Equal(newUser.EMAIL, rr.EMAIL);
        }
    }
}
