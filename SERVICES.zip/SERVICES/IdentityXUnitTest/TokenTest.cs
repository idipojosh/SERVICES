﻿using iCLASSES;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace IdentityXUnitTest
{
    public class TokenTest
    {
        string auth = "1AAAAB+LCAAAAAAAAAsljoENAzEIAweqLGGISTJOq/7vP0KdPhJEmHAmst+" +
            "a91fX0ofcZGhUlNZ9r9n9OkFwF1KBHshKjABrYGxwDjAXvArGxlPZOsNMgXK7zidhuu2w3AY" +
            "6zRNk3VI9qE2o/qZZXmTBzsfOA/pNTjPWQWUJPoKyEgM+i+2M/AHaS48S1AAAAA==";
        string url = "http://localhost:22205/api/token/";

        [Fact]
        public async Task PostToken_PostSingleToken()
        {
            iDTO.PostTOKEN token = new iDTO.PostTOKEN
            {
                USERID = 1,
                TOKENTYPE = "API TOKEN"
            };

            HttpClient client = new HttpClient();

            var json = JsonConvert.SerializeObject(token);
            var stringContent = new StringContent(json, UnicodeEncoding.UTF8, "MediaTypeNames.Application.Json");

            iDTO.PostTOKEN result = D.TO.iMAP<iDTO.PostTOKEN, TOKEN>(await client.PostAsync(url, stringContent));

            Assert.Equal(token.TOKENTYPE, result.TOKENTYPE);
        }

        [Fact]
        public async Task GetTOKEN_ReturnTrue()
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authentication", auth);
            var result = Convert.ToBoolean(await client.GetStringAsync(url));

            Assert.Equal(result, true);
        }
    }
}
