﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace IdentityService.Migrations
{
    public partial class _2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TOKEN_TOKEN_TYPE_TOKEN_TYPEID",
                table: "TOKEN");

            migrationBuilder.AlterColumn<int>(
                name: "TOKEN_TYPEID",
                table: "TOKEN",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AddColumn<int>(
                name: "TTYPEID",
                table: "TOKEN",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_TOKEN_TOKEN_TYPE_TOKEN_TYPEID",
                table: "TOKEN",
                column: "TOKEN_TYPEID",
                principalTable: "TOKEN_TYPE",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TOKEN_TOKEN_TYPE_TOKEN_TYPEID",
                table: "TOKEN");

            migrationBuilder.DropColumn(
                name: "TTYPEID",
                table: "TOKEN");

            migrationBuilder.AlterColumn<int>(
                name: "TOKEN_TYPEID",
                table: "TOKEN",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_TOKEN_TOKEN_TYPE_TOKEN_TYPEID",
                table: "TOKEN",
                column: "TOKEN_TYPEID",
                principalTable: "TOKEN_TYPE",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
