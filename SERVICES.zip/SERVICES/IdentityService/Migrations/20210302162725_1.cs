﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace IdentityService.Migrations
{
    public partial class _1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TOKEN_TYPE",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    NAME = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TOKEN_TYPE", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "USER",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FULL_NAME = table.Column<string>(nullable: false),
                    EMAIL = table.Column<string>(nullable: false),
                    PASSWORD = table.Column<string>(nullable: false),
                    PKEY = table.Column<string>(nullable: false),
                    PIV = table.Column<string>(nullable: false),
                    CREATE_DATE = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_USER", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TOKEN",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    token = table.Column<string>(nullable: false),
                    CREATE_DATE = table.Column<DateTime>(nullable: false),
                    USERID = table.Column<int>(nullable: false),
                    TOKEN_TYPEID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TOKEN", x => x.ID);
                    table.ForeignKey(
                        name: "FK_TOKEN_TOKEN_TYPE_TOKEN_TYPEID",
                        column: x => x.TOKEN_TYPEID,
                        principalTable: "TOKEN_TYPE",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TOKEN_USER_USERID",
                        column: x => x.USERID,
                        principalTable: "USER",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TOKEN_TOKEN_TYPEID",
                table: "TOKEN",
                column: "TOKEN_TYPEID");

            migrationBuilder.CreateIndex(
                name: "IX_TOKEN_USERID",
                table: "TOKEN",
                column: "USERID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TOKEN");

            migrationBuilder.DropTable(
                name: "TOKEN_TYPE");

            migrationBuilder.DropTable(
                name: "USER");
        }
    }
}
