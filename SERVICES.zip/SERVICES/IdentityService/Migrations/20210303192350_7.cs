﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace IdentityService.Migrations
{
    public partial class _7 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TOKEN_TOKEN_TYPE_TOKEN_TYPEID",
                table: "TOKEN");

            migrationBuilder.DropTable(
                name: "TOKEN_TYPE");

            migrationBuilder.DropIndex(
                name: "IX_TOKEN_TOKEN_TYPEID",
                table: "TOKEN");

            migrationBuilder.DropColumn(
                name: "TOKEN_TYPEID",
                table: "TOKEN");

            migrationBuilder.DropColumn(
                name: "TTYPEID",
                table: "TOKEN");

            migrationBuilder.RenameColumn(
                name: "FULL_NAME",
                table: "USER",
                newName: "NAME");

            migrationBuilder.AddColumn<string>(
                name: "TOKENTYPE",
                table: "TOKEN",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TOKENTYPE",
                table: "TOKEN");

            migrationBuilder.RenameColumn(
                name: "NAME",
                table: "USER",
                newName: "FULL_NAME");

            migrationBuilder.AddColumn<int>(
                name: "TOKEN_TYPEID",
                table: "TOKEN",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TTYPEID",
                table: "TOKEN",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "TOKEN_TYPE",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    NAME = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TOKEN_TYPE", x => x.ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TOKEN_TOKEN_TYPEID",
                table: "TOKEN",
                column: "TOKEN_TYPEID");

            migrationBuilder.AddForeignKey(
                name: "FK_TOKEN_TOKEN_TYPE_TOKEN_TYPEID",
                table: "TOKEN",
                column: "TOKEN_TYPEID",
                principalTable: "TOKEN_TYPE",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
