﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using iCLASSES;
using Microsoft.AspNetCore.Mvc;

namespace IdentityService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private iCTXT XEC = new iCTXT();

        [HttpPost]
        public IActionResult PostUSER(iDTO.PostUSER user)
        {
            if (user==null | !ModelState.IsValid |
                null != XEC.USER.SingleOrDefault(m => m.EMAIL.ToUpper() == user.EMAIL.ToUpper()))
            {
                return BadRequest();
            }
            else {
                USER dbUser = D.TO.iMAP<USER, iDTO.PostUSER>(user);

                string[] eRslt= iCRYPT.CreateAesEncryptedPassword(user.PASSWORD);
                dbUser.PASSWORD = eRslt[0];
                dbUser.PKEY = eRslt[1];
                dbUser.PIV = eRslt[2];
                dbUser.CREATE_DATE = DateTime.Now;
                dbUser = XEC.USER.Add(dbUser).Entity;
                XEC.SaveChanges();

                return Ok(D.TO.iMAP<iDTO.GetUSER,USER>(dbUser));
            }
        }
        [HttpGet]
        public IActionResult GetUSER(int Id)
        {
            if (Id< 1)
            {
                return BadRequest();
            }
            else
            {
                var user = XEC.USER.SingleOrDefault(m => m.ID == Id);

                if (user == null) { return NotFound(); }

                else { return Ok(D.TO.iMAP<iDTO.GetUSER, USER>(user)); }
            }
        }
    }
}
