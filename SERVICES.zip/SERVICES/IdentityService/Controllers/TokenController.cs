﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using iCLASSES;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace IdentityService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        private iCTXT XEC = new iCTXT();
        
        [HttpPost]
        public IActionResult PostTOKEN(iDTO.PostTOKEN token) 
        {
            TOKEN dbTkn = D.TO.iMAP<TOKEN, iDTO.PostTOKEN>(token);

            dbTkn.CREATE_DATE = DateTime.Now;
            dbTkn.token = iCRYPT.CreateAesEncryptedToken((DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond).ToString());

            dbTkn = XEC.TOKEN.Add(dbTkn).Entity;
            XEC.SaveChanges();
            return Ok(dbTkn);
        }
        [HttpGet]
        public async Task<bool> GetTOKEN() 
        {
            string auth = HttpContext.Request.Headers["Authentication"];
            if (string.IsNullOrWhiteSpace(auth))
            {
                return false;
            }
            else
            {
                iCTXT XEC = new iCTXT();
                var authXsts = await Task.Run(() => XEC.TOKEN.SingleOrDefault(m => m.token == auth));
                if (authXsts == null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
    }
}
