﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Configuration;
using System.Data;

namespace iCLASSES
{
    public class iDTO
    {
        public class PostUSER
        {
            [Required]
            public string NAME { get; set; }
            [Required]
            public string EMAIL { get; set; }
            [Required]
            public string PASSWORD { get; set; }
        }
        public class GetUSER
        {
            [Required]
            public int ID { get; set; }
            [Required]
            public string NAME { get; set; }
            [Required]
            public string EMAIL { get; set; }
            [Required]
            public string PASSWORD { get; set; }
            [Required]
            public DateTime CREATE_DATE { get; set; }
        }
        public class PostTOKEN
        {
            public int USERID { get; set; }
            [Required]
            public string TOKENTYPE { get; set; }
        }
    }
}