﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace iCLASSES
{
    public class iCTXT : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=DESKTOP-39I5CTE;Initial Catalog=IdentityService;Integrated Security=True");
        }

        public DbSet<USER> USER { get; set; }
        public DbSet<TOKEN> TOKEN { get; set; }
    }
}