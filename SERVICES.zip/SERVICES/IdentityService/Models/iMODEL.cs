﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace iCLASSES
{
    public class USER
    {
        public int ID { get; set; }
        [Required]
        public string NAME { get; set; }
        [Required]
        public string EMAIL { get; set; }
        [Required]
        public string PASSWORD { get; set; }
        [Required]
        public string PKEY { get; set; }
        [Required]
        public string PIV { get; set; }
        public DateTime CREATE_DATE { get; set; }
    }
    public class TOKEN
    {
        public int ID { get; set; }
        [Required]
        public string token { get; set; }
        public string TOKENTYPE { get; set; }
        public DateTime CREATE_DATE { get; set; }
        public int USERID { get; set; }
        public USER USER { get; set; }
    }
}