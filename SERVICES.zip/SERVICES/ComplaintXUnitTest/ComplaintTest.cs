using cCLASSES;
using ComplaintService.Controllers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ComplaintXUnitTest
{
    public class ComplaintTest
    {
        [Fact]
        public async Task PostCOMPLAINT_PostSingleComplaint()
        {
            cDTO.PostCOMPLAINT complaint = new cDTO.PostCOMPLAINT
            {
                DESCRIPTION = "Unable To Login",
                STATUS = "PENDING",
                PRODUCT = "GOLD PRODUCT"
            };

            var contrl = new ComplaintController();
            var mm = await contrl.PostCOMPLAINT(complaint);

            Assert.Equal(complaint, D.TO.iMAP<cDTO.PostCOMPLAINT, COMPLAINT>(mm));
        }

        [Fact]
        public async Task GetCOMPLAINT_ReturnSingleComplaint()
        {
            int id = 1;

            var controller = new ComplaintController();

            var result = (COMPLAINT)await controller.GetCOMPLAINT(id);
            Assert.Equal(id, result.ID);
        }

        [Fact]
        public async Task GetCOMPLAINTS_ReturnAllComplaint()
        {
            var controller = new ComplaintController();

            var complaint1 = (List<COMPLAINT>)await controller.GetCOMPLAINTS();

            Assert.IsType<List<COMPLAINT>>(complaint1);
        }

        [Fact]
        public async Task PatchCOMPLAINT_ReturnUpdatedComplaint()
        {
            cDTO.PostCOMPLAINT poComplaint = new cDTO.PostCOMPLAINT
            {
                DESCRIPTION = "Unable To Login",
                STATUS = "PENDING",
                PRODUCT = "GOLD PRODUCT"
            };

            var controller = new ComplaintController();
            var oldComplaint = (COMPLAINT)await controller.PostCOMPLAINT(poComplaint);

            cDTO.PatchCOMPLAINT paComplaint = new cDTO.PatchCOMPLAINT
            {
                ID = oldComplaint.ID,
                STATUS = "SOLVED"
            };

            var newComplaint = (COMPLAINT)await controller.PatchCOMPLAINT(paComplaint);
            Assert.NotEqual(oldComplaint, newComplaint);
        }

    }
}
