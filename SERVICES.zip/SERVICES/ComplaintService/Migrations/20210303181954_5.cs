﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ComplaintService.Migrations
{
    public partial class _5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_COMPLAINT_CSTATUS_CSTATUSID",
                table: "COMPLAINT");

            migrationBuilder.DropForeignKey(
                name: "FK_COMPLAINT_PRODUCT_PRODUCTID",
                table: "COMPLAINT");

            migrationBuilder.DropTable(
                name: "CSTATUS");

            migrationBuilder.DropTable(
                name: "PRODUCT");

            migrationBuilder.DropIndex(
                name: "IX_COMPLAINT_CSTATUSID",
                table: "COMPLAINT");

            migrationBuilder.DropIndex(
                name: "IX_COMPLAINT_PRODUCTID",
                table: "COMPLAINT");

            migrationBuilder.DropColumn(
                name: "CSTATUSID",
                table: "COMPLAINT");

            migrationBuilder.DropColumn(
                name: "PRODUCTID",
                table: "COMPLAINT");

            migrationBuilder.RenameColumn(
                name: "NAME",
                table: "COMPLAINT",
                newName: "STATUS");

            migrationBuilder.AlterColumn<string>(
                name: "TOKEN",
                table: "COMPLAINT",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DESCRIPTION",
                table: "COMPLAINT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PRODUCT",
                table: "COMPLAINT",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DESCRIPTION",
                table: "COMPLAINT");

            migrationBuilder.DropColumn(
                name: "PRODUCT",
                table: "COMPLAINT");

            migrationBuilder.RenameColumn(
                name: "STATUS",
                table: "COMPLAINT",
                newName: "NAME");

            migrationBuilder.AlterColumn<string>(
                name: "TOKEN",
                table: "COMPLAINT",
                nullable: true,
                oldClrType: typeof(string));

            migrationBuilder.AddColumn<int>(
                name: "CSTATUSID",
                table: "COMPLAINT",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "PRODUCTID",
                table: "COMPLAINT",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "CSTATUS",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    NAME = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CSTATUS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PRODUCT",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    NAME = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PRODUCT", x => x.ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_COMPLAINT_CSTATUSID",
                table: "COMPLAINT",
                column: "CSTATUSID");

            migrationBuilder.CreateIndex(
                name: "IX_COMPLAINT_PRODUCTID",
                table: "COMPLAINT",
                column: "PRODUCTID");

            migrationBuilder.AddForeignKey(
                name: "FK_COMPLAINT_CSTATUS_CSTATUSID",
                table: "COMPLAINT",
                column: "CSTATUSID",
                principalTable: "CSTATUS",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_COMPLAINT_PRODUCT_PRODUCTID",
                table: "COMPLAINT",
                column: "PRODUCTID",
                principalTable: "PRODUCT",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
