﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace cCLASSES
{
    public static class cCRYPT
    {
        public static string CreateAesEncryptedToken(string plainText)
        {
            //plainText should be userName+Password to produce a distinct encryption
            // Check arguments.
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");

            byte[] encrypted, Key, IV;

            // Encrypt the string to an array of bytes
            // and store the encryption, Key & IV strings in encrypted[0], [1] & [2] respectively.

            // Create a new instance of the Aes class.
            // This generates a new key and initialization vector (IV).
            using (Aes aesAlg = Aes.Create())
            {
                Key = aesAlg.Key;
                IV = aesAlg.IV;

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {

                    // Create an encryptor to perform the stream transform.
                    ICryptoTransform encryptor = aesAlg.CreateEncryptor(Key, IV);
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            string[] result = new string[3];
            int k = encrypted.Length;

            // Convert byte array(encrypted) to a string and put it in result[0]
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < k; i++)
            {
                builder.Append(encrypted[i].ToString("x2"));
            }
            result[0] = builder.ToString();

            k = Key.Length;
            // Convert byte array(Key) to a string and put it in result[1]
            for (int i = 0; i < k; i++)
            {
                if (i != 0) { result[1] += "-" + Key[i].ToString(); }
                else { result[1] += Key[i].ToString(); }
            }

            k = IV.Length;
            // Convert byte array(IV) to a string and put it in result[2]
            for (int i = 0; i < k; i++)
            {
                if (i != 0) { result[2] += "-" + IV[i].ToString(); }
                else { result[2] += IV[i].ToString(); }
            }

            //This result can now be saved in the database as the users' login encryption data
            //return result;

            string dlmtr = "+++++";
            return CompressString(result[0] + dlmtr + result[1] + dlmtr + result[2]);
        }
        public static string[] CreateAesEncryptedPassword(string plainText)
        {
            //plainText should be userName+Password to produce a distinct encryption
            // Check arguments.
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");

            byte[] encrypted, Key, IV;

            // Encrypt the string to an array of bytes
            // and store the encryption, Key & IV strings in encrypted[0], [1] & [2] respectively.

            // Create a new instance of the Aes class.
            // This generates a new key and initialization vector (IV).
            using (Aes aesAlg = Aes.Create())
            {
                Key = aesAlg.Key;
                IV = aesAlg.IV;

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {

                    // Create an encryptor to perform the stream transform.
                    ICryptoTransform encryptor = aesAlg.CreateEncryptor(Key, IV);
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            string[] result = new string[3];
            int k = encrypted.Length;

            // Convert byte array(encrypted) to a string and put it in result[0]
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < k; i++)
            {
                builder.Append(encrypted[i].ToString("x2"));
            }
            result[0] = builder.ToString();

            k = Key.Length;
            // Convert byte array(Key) to a string and put it in result[1]
            for (int i = 0; i < k; i++)
            {
                if (i != 0) { result[1] += "-" + Key[i].ToString(); }
                else { result[1] += Key[i].ToString(); }
            }

            k = IV.Length;
            // Convert byte array(IV) to a string and put it in result[2]
            for (int i = 0; i < k; i++)
            {
                if (i != 0) { result[2] += "-" + IV[i].ToString(); }
                else { result[2] += IV[i].ToString(); }
            }

            //This result can now be saved in the database as the users' login encryption data
            result[0] = CompressString(result[0]); //PASWORD
            result[1] = CompressString(result[1]); //KEY
            result[2] = CompressString(result[2]); //IV

            return result;
        }
        public static string DecryptAesEncryptedPassword(string plainText, string DBKey, string DBIV)
        {
            //plainText should be userName+Password to produce a distinct encryption
            // Check arguments.
            if (plainText == null || plainText.Length <= 0 ||
                DBKey == null || DBKey.Length <= 0 ||
                DBIV == null || DBIV.Length <= 0)
                throw new ArgumentNullException("plainText");

            byte[] encrypted, Key, IV;
            Key = stringToBytes_Array(DecompressString(DBKey));
            IV = stringToBytes_Array(DecompressString(DBIV));
            plainText = DecompressString(plainText);

            // Create a new instance of the Aes class.
            // This generates a new key and initialization vector (IV).
            using (Aes aesAlg = Aes.Create())
            {
                // Create an encryptor to perform the stream transform.
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(Key, IV);

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            string result;
            int k = encrypted.Length;

            // Convert byte array(encrypted) to a string and put it in result
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < k; i++)
            {
                builder.Append(encrypted[i].ToString("x2"));
            }
            result = builder.ToString();

            //This result can now be compared with the users' encrypted password in the DB
            return result;
        }
        private static byte[] stringToBytes_Array(string KeyOrIV)
        {
            string[] KeyOrIV1 = KeyOrIV.Split('-');
            int KeyOrIV1Length = KeyOrIV1.Length;

            byte[] KeyOrIV2 = new byte[KeyOrIV1Length];

            for (int i = 0; i < KeyOrIV1Length; i++)
            {
                KeyOrIV2[i] = Convert.ToByte(KeyOrIV1[i]);
            }

            return KeyOrIV2;
        }
        private static string CompressString(string text)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(text);
            var memoryStream = new MemoryStream();
            using (var gZipStream = new GZipStream(memoryStream, CompressionMode.Compress, true))
            {
                gZipStream.Write(buffer, 0, buffer.Length);
            }

            memoryStream.Position = 0;

            var compressedData = new byte[memoryStream.Length];
            memoryStream.Read(compressedData, 0, compressedData.Length);

            var gZipBuffer = new byte[compressedData.Length + 4];
            Buffer.BlockCopy(compressedData, 0, gZipBuffer, 4, compressedData.Length);
            Buffer.BlockCopy(BitConverter.GetBytes(buffer.Length), 0, gZipBuffer, 0, 4);

            return Convert.ToBase64String(gZipBuffer);
        }
        private static string DecompressString(string compressedText)
        {
            byte[] gZipBuffer = Convert.FromBase64String(compressedText);
            using (var memoryStream = new MemoryStream())
            {
                int dataLength = BitConverter.ToInt32(gZipBuffer, 0);
                memoryStream.Write(gZipBuffer, 4, gZipBuffer.Length - 4);

                var buffer = new byte[dataLength];

                memoryStream.Position = 0;
                using (var gZipStream = new GZipStream(memoryStream, CompressionMode.Decompress))
                {
                    gZipStream.Read(buffer, 0, buffer.Length);
                }

                return Encoding.UTF8.GetString(buffer);
            }
        }

    }
}