﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace cCLASSES
{
    public class cCTXT : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=DESKTOP-39I5CTE;Initial Catalog=ComplaintService;Integrated Security=True");
        }

        public DbSet<COMPLAINT> COMPLAINT { get; set; }
    }
}