﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace cCLASSES
{
    public static class cAUTH
    {
        public static async Task<bool> AuthUser(string auth)
        {
            if (string.IsNullOrWhiteSpace(auth)) { return false; }
            else {
                HttpClient client = new HttpClient();

                var url = "http://localhost:22205/api/token/";

                client.DefaultRequestHeaders.Add("Authentication", auth);

                var ret = Convert.ToBoolean(await client.GetStringAsync(url));

                return ret;
            }
        }
    }
}