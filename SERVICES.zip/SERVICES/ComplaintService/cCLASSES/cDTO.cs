﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace cCLASSES
{
    public class cDTO
    {
        public class PostCOMPLAINT
        {
            [Required]
            public string DESCRIPTION { get; set; }
            [Required]
            public string STATUS { get; set; }
            [Required]
            public string PRODUCT { get; set; }
        }
        public class PatchCOMPLAINT
        {
            public int ID { get; set; }
            [Required]
            public string STATUS { get; set; }
        }
    }
}