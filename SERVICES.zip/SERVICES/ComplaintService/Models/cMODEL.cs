﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace cCLASSES
{
    public class COMPLAINT
    {
        public int ID { get; set; }
        [Required]
        public string DESCRIPTION { get; set; }
        [Required]
        public string PRODUCT { get; set; }
        [Required]
        public string STATUS { get; set; }
        [Required]
        public string TOKEN { get; set; }
        public DateTime CREATE_DATE { get; set; }
    }
}