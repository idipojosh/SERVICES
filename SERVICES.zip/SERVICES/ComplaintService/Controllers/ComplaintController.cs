﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using cCLASSES;
using System.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using D;

namespace ComplaintService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComplaintController : ControllerBase
    {
        private cCTXT XEC = new cCTXT();

        [HttpPost]
        public async  Task<IActionResult> PostCOMPLAINT(cDTO.PostCOMPLAINT complaint)
        {
            if (!(await cAUTH.AuthUser(HttpContext.Request.Headers["Authentication"])))
            {
                return Unauthorized();
            }
            else {
                COMPLAINT dbCplt = D.TO.iMAP<COMPLAINT, cDTO.PostCOMPLAINT>(complaint);

                dbCplt.TOKEN = HttpContext.Request.Headers["Authentication"];
                dbCplt.CREATE_DATE = DateTime.Now;

                dbCplt = XEC.COMPLAINT.Add(dbCplt).Entity;
                XEC.SaveChanges();
                return Ok(dbCplt);
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetCOMPLAINT(int id)
        {
            if (!(await cAUTH.AuthUser(HttpContext.Request.Headers["Authentication"])))
            {
                return Unauthorized();
            }
            else {
                var complaint = XEC.COMPLAINT.SingleOrDefault(m => m.ID == id);
                if (complaint == null)
                {
                    return NotFound();
                }
                else { return Ok(complaint); }
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetCOMPLAINTS()
        {
            if (!(await cAUTH.AuthUser(HttpContext.Request.Headers["Authentication"])))
            {
                return Unauthorized();
            }
            else {
                return Ok(XEC.COMPLAINT.ToList());
            }
        }
        [HttpPatch]
        public async Task<IActionResult> PatchCOMPLAINT(cDTO.PatchCOMPLAINT complaint)
        {
            if (!(await cAUTH.AuthUser(HttpContext.Request.Headers["Authentication"])))
            {
                return Unauthorized();
            }
            else
            {
                COMPLAINT validComplaint = XEC.COMPLAINT.SingleOrDefault(m =>
                m.ID == complaint.ID);
                if (validComplaint == null)
                {
                    return NotFound();
                }
                else
                {
                    validComplaint.STATUS = complaint.STATUS;

                    XEC.SaveChanges();
                    return Ok(validComplaint);
                }
             }
        }
    }
}
